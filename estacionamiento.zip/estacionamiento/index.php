<?php

date_default_timezone_set('America/Argentina/Buenos_Aires');

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">


	 <title>Sistema de cobro de estacionamiento</title>

  <link rel="stylesheet" href="dist/css/bootstrap.min.css">

  <script src="js/jquery.min.js"></script>

  <script src="js/bootstrap.min.js"></script>

  <link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>


 
  <script type="text/javascript" src="DataTables/datatables.min.js"></script>

  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">


    
    <style type="text/css">


    body{

              background-color: #969CA6;


    }


    .headerMenu

                {

                    background-color: #E2E3E5;

                    min-height: 80px;



                }


    .logoMenu{


        width: 80px;




    }

    .texTitulo{


        font-size: 1.5em;

        color: #082457;

        padding: 1.3%;

        font: bold monospace;


    }
    .paddininput
    {
      padding: 2%;
    }

                                 

    </style>

</head>
<body>

<nav class="navbar headerMenu">

  <div class="container-fluid">


        <div class="row">

            <div class="col-sm-1">

              <br>

              <img src="img/logo1.png" class="logoMenu" align="right"> </img>

            </div>


            <div class="col-sm-5">

              <br>

              <h5 class="texTitulo">Sistema de estacionamiento</h5>

            </div>

            <div class="col-sm-6">

            <div style="text-align:center;padding:1em 0;" align="right"> </div>

            </div>
    </div>

  </div>
          
</nav>

<?php

function listadecobro()
{

$servername = "localhost";
$username = "quiroga";
$password = "";
$dbname = "estacionamiento";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 



  $sql = "SELECT * FROM tipotarifa";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo '<option value="'.$row['idtipoTarifa'].'">'.$row['idtipoTarifa']. '-'.$row['nombreTipo']." </option> <br>";
    }
  } else {
    echo "0 results";
  }
$conn->close();
}


function listadevehiculos()
{

$servername = "localhost";
$username = "quiroga";
$password = "";
$dbname = "estacionamiento";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 



  $sql = "SELECT * FROM tipovehiculo";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo '<option value="'.$row['idtipoVehiculo'].'">'.$row['idtipoVehiculo']. '-'.$row['tipoVehiculo']." </option> <br>";
    }
  } else {
    echo "0 results";
  }
$conn->close();
}

?>
  
 <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content paddininput">
<h1 style="text-align:center" > Movimiento de Vehiculo</h1>
<div class="row">

  <div class="col-md-4">

    <label>Tipo vehiculo</label><br>
      <select name="tipoVehiculo" class="form-control paddininput" > 

        <?php 
            listadevehiculos();
         ?>
         
    </select>

  </div>


  <div class="col-md-4">

    <label>Hora entrada vehiculo</label><br>
    <input type="time" name="entrada" class="form-control">

  </div>

  <div class="col-md-4"> 

    <label>Hora salida vehiculo</label>
    <input type="time" name="salida" class="form-control">

  </div>

</div>


<div class="row">

  <div class="col-md-4">
      <label>Cobro</label><br>
      <input type="text" name="cobro" class="form-control">
             
 </div>


  <div class="col-md-4">

      <label>Color</label>
      <input type="text" name="color" class="form-control">
  </div>

  <div class="col-md-4"> 

      <label> tipos de cobros </label>
      <select name="tipocobro" class="form-control"> 


      <?php 
          listadecobro();
       ?>

       </select><br>

  </div>
</div>




<div class="row">

  <div class="col-md-4">
      <label>Usuario</label>
      <input type="text" name="usuario" class="form-control">
             
 </div>


  <div class="col-md-4">

       <label>Contraseña</label>
       <input type="password" name="contrasenia" class="form-control">
  </div>


  <div class="col-md-4">

         <label>patente</label>
       <input type="text" name="patente" class="form-control">
       
  </div>

  <div class="col-md-4">

        <br>
       <input type="submit" name="" class="btn btn-md" style="color:black; width: 100%" align="center">
  </div>

</div>


<br> <br>


          <div class="container box">

            <div class="table-responsive">
                    <table id="employee-grid" class="table table-striped"  cellspacing="0" style="width: 50%">
                      <thead>
                        <tr>
                          <th>idmovimientos</th>
                          <th>tipoVehiculo_idtipoVehiculo</th>     
                        </tr>
                      </thead>
                    </table>
                    
                  </div>
            </div>     
      
      
     
       
     

      

    </div>
  </div>
</div>
<br>  




<div class="container">


  <table class="table" style="width: 100%">
    <thead>
      <tr>
        <th width="5%"></th>
        <th width="30%"></th>
        <th width="60%"></th>

      </tr>
    </thead>
    <tbody>



      <tr>
        <td align="center"> </td>
        <td align="center"><img src="img/icono-carro.png" alt="Movimientos" style="width:30%;"></td>
        <td align="center"><p style="text-align: left; color: #E2E3E5; font-size: 2em"> Movimientos de vehiculos
        <button type="button" class="btn btn-md" data-toggle="modal" data-target=".bs-example-modal-lg" style="color:black">Ingresar</button></p>



        <p style="text-align: left; color: #22427B; font-size: 1em; padding-right: 2%"> <i class="material-icons" style="font-size:20px;color:#082457">help_outline</i> Informacion sobre las horas de entradas, salidas de los vehiculos y tarifas cobradas</p></td>

        </tr>

      <tr>
        <td align="center"> </td>
        <td align="center"><img src="img/icono-carro.png" alt="Movimientos" style="width:30%;"></td>
        <td align="center"><p style="text-align: left; color: #E2E3E5; font-size: 1.5em"> Movimientos de vehiculos <button class="btn btn-md" style="color: black"> Ingresar </button></p>


        <p style="text-align: left; color: #22427B; font-size: 1em; padding-right: 2%"> <i class="material-icons" style="font-size:20px;color:#082457">help_outline</i> Informacion sobre las horas de entradas, salidas de los vehiculos y tarifas cobradas</p></td>

        </tr>

      <tr>
        <td align="center"> </td>
        <td align="center"><img src="img/icono-carro.png" alt="Movimientos" style="width:30%;"></td>
        <td align="center"><p style="text-align: left; color: #E2E3E5; font-size: 1.5em"> Movimientos de vehiculos <button class="btn btn-md" style="color: black"> Ingresar </button></p>


        <p style="text-align: left; color: #22427B; font-size: 1em; padding-right: 2%"> <i class="material-icons" style="font-size:20px;color:#082457">help_outline</i> Informacion sobre las horas de entradas, salidas de los vehiculos y tarifas cobradas</p></td>

        </tr>

    </tbody>
  </table>




    <script type="text/javascript" language="javascript" >
      $(document).ready(function() {
     /* 
        var dataTable =  $('#employee-grid').DataTable( {
        processing: true,
        serverSide: true,
        ajax: "employee-grid-data.php", // json datasource

        dom: 'B<"clear">',
        buttons: [
            {
                text: 'Imprimir',
                extend: 'print',

                exportOptions: { orthogonal: 'export', 
                                 }
            },
            {
                text: 'Excel',
                extend: 'excelHtml5',
                exportOptions: { orthogonal: 'export' }
            },
            {
                text: 'PDF',
                extend: 'pdfHtml5',
                exportOptions: { orthogonal: 'export' }
            }
        ]

        } );// hiding global search box
        

    

      } );

      */

    </script>


        <br /> <br />






</body>

</html>



